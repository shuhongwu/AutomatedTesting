#!/bin/bash

EMAILMESSAGE="/tmp/motion"

size=`du -hs /tmp/motion/ | cut -f 1`
echo $size
sleep 20

size2=`du -hs /tmp/motion/ | cut -f 1`
echo $size2


if [ $size = $size2 ]; then
	echo "Both Values are equal"
        #zip -r /tmp/motion.zip /tmp/motion
        #mpack -s "file you wanted" /tmp/motion.zip ws169144@163.com

else 
	echo "Values are NOT equal"
        zip -r /tmp/motion.zip /tmp/motion
        mpack -s "file I wanted" /tmp/motion.zip ws169144@163.com
fi
